function getEdit(abc)
{
	alert(abc);
	redirect(abc)
}

function redirect()
{
	
	 var json = {"filrname":abc}; 

		
  	$.ajax({
  	
  		url : 'http://localhost:8080/testCase/getEdit',
  		
  		data : JSON.stringify(json),
  		type : "POST",

  		beforeSend : function(xhr) {
  			xhr.setRequestHeader("Accept", "application/json");
  			xhr.setRequestHeader("Content-Type", "application/json");
  		},
  		success : function(response) {	
  			
  			$("#Product_Name").val(response[0].Product_Name);
  			$("#Templet_Name").val(response[0].Templet_Name);
  			$("#Product_Description").val(response[0].Product_Description);
  			$("#Merchandise_Type").val(response[0].Merchandise_Type);
  			$("#Retail_Price").val(response[0].Retail_Price);
  			$("#Property").val(response[0].Property);
  			$("#Lunch_Year").val(response[0].Lunch_Year);
  			$("#Lunch_Season").val(response[0].Lunch_Season);
  			$("#Event_Special").val(response[0].Event_Special); 			
  			$("#Distribution_Territory").val(response[0].Distribution_Territory);
  			$("#Team").val(response[0].Team);
  			$("#Player_used").val(response[0].Player_used);
  			$("#Product_Type").val(response[0].Product_Type);
  			$("#hidden_id").val(response[0].id);
  			
  			location.href = 'index.html';
  			
  		},

  	});

  	event.preventDefault(); 

	 

	
	
	}
	