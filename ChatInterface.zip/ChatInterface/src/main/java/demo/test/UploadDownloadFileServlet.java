package demo.test;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@WebServlet("/UploadDownloadFileServlet")
public class UploadDownloadFileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private ServletFileUpload uploader = null;
	@Override
	public void init() throws ServletException{
		
		DiskFileItemFactory fileFactory = new DiskFileItemFactory();
		String rootPath = System.getProperty("catalina.home");
    	File file = new File(rootPath + File.separator + "tmpfiles");
    	if(!file.exists()) file.mkdirs();
        File filesDir = file;
		System.out.println("filesDir" + filesDir);
		fileFactory.setRepository(filesDir);
		this.uploader = new ServletFileUpload(fileFactory);
	}
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username1 ="";
		String username2 ="";
		String username3 ="";
		String username4 ="";
		String username5 ="";
		String username6 ="";
		String username7 ="";
		String username8 ="";
		String username9 ="";
		String username10 ="";
		String username11 ="";
		String username12 ="";
		String username13 ="";
		String username14 ="";
		String username15 ="";
		String filepath="";
		String value ="";
		String path="";
		System.out.println("post");
		if(!ServletFileUpload.isMultipartContent(request)){
			throw new ServletException("Content type is not multipart/form-data");
		}
		   //response.setContentType("application/json; charset=utf-8");
		request.getContentType();
		System.out.println("request.getContentType();" + request.getContentType());
		PrintWriter out = response.getWriter();
		out.write("<html><head></head><body>");
		System.out.println(request.getParameterValues("firstname"));
		String inputName = null;
		try {
			List<FileItem> fileItemsList = uploader.parseRequest(request);
			System.out.println("fileItemsList" + fileItemsList.toString());
			Iterator<FileItem> fileItemsIterator = fileItemsList.iterator();
			while(fileItemsIterator.hasNext()){
				
					  
				FileItem fileItem = fileItemsIterator.next();
				System.out.println("FieldName="+fileItem.getFieldName());
				System.out.println("FileName="+fileItem.getName());
				System.out.println("ContentType="+fileItem.getContentType());
				System.out.println("Size in bytes="+fileItem.getSize());
				
			
				System.out.println(File.separator);
				System.out.println(System.getProperty("catalina.home") + File.separator + "tmpfiles");
				String tr="C:\\Users\\Altruist\\Desktop\\tomcat\\tmpfiles";
				File file = new File(tr + File.separator+fileItem.getName());
				System.out.println("Absolute Path at server="+file.getAbsolutePath());

				 path =fileItem.getName();
				 filepath = file.getAbsolutePath();
				fileItem.write(file);
				
				 if(fileItem.isFormField()){  // Check regular field.
					  inputName = (String)fileItem.getFieldName(); 
					System.out.println("inputName of fild:-" +inputName);
					
					if(inputName.equalsIgnoreCase("Product_Name")){ 
						 username1 = (String)fileItem.getString(); 
						          System.out.println("SECHDULE FILE NAME is:"+username1); 
						  }
					if(inputName.equalsIgnoreCase("Product_Description")){ 
						 username2 = (String)fileItem.getString(); 
						 
						          System.out.println("SECHDULE DATE TIME is:"+username2); 
						  }
					if(inputName.equalsIgnoreCase("Merchandise_Type")){ 
						 username3 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username3); 
						  }
					
					
					if(inputName.equalsIgnoreCase("Retail_Price")){ 
						 username4 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username4); 
						  }
					

					if(inputName.equalsIgnoreCase("Property")){ 
						 username5 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username5); 
						  }
					
					
					if(inputName.equalsIgnoreCase("Lunch_Year")){ 
						 username6 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username6); 
						  }
					
					if(inputName.equalsIgnoreCase("Lunch_Season")){ 
						 username7 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username7); 
						  }
					
					
					
					
					if(inputName.equalsIgnoreCase("Event_Special")){ 
						 username8 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username8); 
						  }
					
					
					

					if(inputName.equalsIgnoreCase("Distribution_Territory")){ 
						 username9 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username9); 
						  }
					

					if(inputName.equalsIgnoreCase("Team")){ 
						 username10 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username10); 
						  }
					

					if(inputName.equalsIgnoreCase("Player_used")){ 
						 username11 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username11); 
						  }
					
					

					if(inputName.equalsIgnoreCase("Product_Type")){ 
						 username12 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username12); 
						  }
					
					if(inputName.equalsIgnoreCase("hidden_Product_Name")){ 
						 username13 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username13); 
						  }
					
					if(inputName.equalsIgnoreCase("hidden_indicator")){ 
						 username14 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username14); 
						  }
					
					if(inputName.equalsIgnoreCase("hidden_id")){ 
						 username15 = (String)fileItem.getString(); 
					
						          System.out.println("SECHDULE MESSAGE is:"+username15); 
						  }
					
					
					
					
					
				 }
			}
		
			System.out.println("path" + path);
			String sql="";
			if(username15 != null && !username15.isEmpty())
			{
			sql="UPDATE task.submitnewdesign SET Templet_Name= '"+username13+"',Product_Name= '"+username1+"', Product_Description= '"+username2+"', Merchandise_Type='"+username3+"', Retail_Price='"+username4+"', Property='"+username5+"', Lunch_Year='"+username6+"',Lunch_Season='"+username7+"',Event_Special='"+username8+"',Distribution_Territory='"+username9+"',Team='"+username10+"',Player_used='"+username11+"',Product_Type='"+username12+"' WHERE id = '"+Integer.parseInt(username15)+"'";
			Mycon.updateData(sql);
			}
			else
				{if(username14.equals("abcdefgh"))
			{
			
				sql="INSERT INTO task.submitnewdesign (Templet_Name,Product_Name, Product_Description, Merchandise_Type, Retail_Price, Property, Lunch_Year,Lunch_Season,Event_Special,Distribution_Territory,Team,Player_used,Product_Type,imagepath,imagename) VALUES ('"+username13+"','"+username1+"', '"+username2+"', '"+username3+"', '"+username4+"','"+username5+"','"+username6+"','"+username7+"','"+username8+"','"+username9+"','"+username10+"','"+username11+"','"+username12+"','"+filepath+"','"+path+"')";
				 Mycon.insertmessage(sql);
			}
			 
			else
			{
				sql="INSERT INTO task.submitnewdesign (Product_Name, Product_Description, Merchandise_Type, Retail_Price, Property, Lunch_Year,Lunch_Season,Event_Special,Distribution_Territory,Team,Player_used,Product_Type,imagepath,imagename) VALUES ('"+username1+"', '"+username2+"', '"+username3+"', '"+username4+"','"+username5+"','"+username6+"','"+username7+"','"+username8+"','"+username9+"','"+username10+"','"+username11+"','"+username12+"','"+filepath+"','"+path+"')";
					
				 Mycon.insertmessage(sql);
			}
				}
		
		
		
			 out.write("File  uploaded successfully.");
					
			 response.sendRedirect("http://localhost:8080/testCase/reportList.html");  
		
		
		} catch (FileUploadException e) {
			out.write("Exception in uploading file.");
		} catch (Exception e) {
			out.write("Exception in uploading file.");
		}
		out.write("</body></html>");
	}

}
