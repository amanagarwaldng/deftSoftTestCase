package demo.test;

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

/**
 * Servlet implementation class getData
 */
public class getData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getData() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		System.out.println(request);
		
		
		 StringBuilder sb = new StringBuilder();
		    BufferedReader br = request.getReader();
		    String str;
		    while( (str = br.readLine()) != null ){
		        sb.append(str);
		    }    
		   System.out.println(sb.toString());
		
		   final JSONObject obj = new JSONObject(sb.toString());
		 
		  String status1=obj.getString("filrname");
		  
		  System.out.println("status1" + status1);
		   String sql1="";
	
		   if(status1.equals("1"))   
		   {
			 
			   sql1="SELECT  Templet_Name FROM task.submitnewdesign WHERE Templet_Name IS NOT NULL AND Templet_Name != ' '";
			   
		  
		   }
		   
		   else  if(status1.equals("2"))   
		   {
			 
			   sql1="SELECT * FROM task.submitnewdesign";
			   
			   System.out.println("hello aman");
			   
		  
		   }
		   else
		   {
			   sql1=" SELECT * FROM task.submitnewdesign where Templet_Name = '"+status1+"' "; 
			   
		   }
		 
		   
		  String TsmsMo1 = Mycon.searchDatamessage(sql1,status1);
		   
		System.out.println(TsmsMo1);
	
		 response.setContentType("application/json; charset=utf-8");
		    
		    response.getWriter().write(TsmsMo1.toString()); 
	}


}
