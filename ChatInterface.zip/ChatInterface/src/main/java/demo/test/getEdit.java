package demo.test;

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

/**
 * Servlet implementation class getEdit
 */
public class getEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getEdit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 StringBuilder sb = new StringBuilder();
		    BufferedReader br = request.getReader();
		    String str;
		    while( (str = br.readLine()) != null ){
		        sb.append(str);
		    }    
		   System.out.println(sb.toString());
		
		   final JSONObject obj = new JSONObject(sb.toString());
		 
		  int status1=obj.getInt("filrname");
		  
		  System.out.println("status1" + status1);
		   String sql1="";
	
		   
			   sql1="SELECT * FROM task.submitnewdesign WHERE id='"+status1+"'";
			   
		  
		
		 Mycon.insertmessage(sql1);
		   
	
		  String TsmsMo1 = Mycon.searchDatamessageEdit(sql1);
		   
			System.out.println(TsmsMo1);
		
			 response.setContentType("application/json; charset=utf-8");
			    
			    response.getWriter().write(TsmsMo1.toString()); 

	}

	
	

}
