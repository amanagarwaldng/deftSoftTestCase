package demo.test;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.*;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;


public class Mycon {
	
	
	static ConnectionManager connect;
	static private Connection conn = null;
	static private Statement stmt = null;
	static private ResultSet rs = null;

	


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	public static String searchDatamessage(String slq,String status)
	{
		System.out.println(slq);
		JSONArray jsa = new JSONArray();	
		
	try
	{
		
		conn = ConnectionManager.getConnection();
		stmt = conn.createStatement();

	
	rs = stmt.executeQuery(slq);


	while (rs.next()) {


		JSONObject validatejson = new JSONObject();
		if(status.equals("1"))
		{
			validatejson.put("Templet_Name", rs.getString("Templet_Name"));
			
		}
		else if(status.equals("2"))
		{
			validatejson.put("id", rs.getInt("id"));	
			validatejson.put("Templet_Name", rs.getString("Templet_Name"));	
			validatejson.put("Product_Name", rs.getString("Product_Name"));
			validatejson.put("Product_Description", rs.getString("Product_Description"));	
			validatejson.put("Merchandise_Type", rs.getString("Merchandise_Type"));
			validatejson.put("Retail_Price", rs.getString("Retail_Price"));	
			validatejson.put("Property", rs.getString("Property"));
			validatejson.put("Lunch_Year", rs.getString("Lunch_Year"));	
			validatejson.put("Lunch_Season", rs.getString("Lunch_Season"));
			validatejson.put("Event_Special", rs.getString("Event_Special"));	
			validatejson.put("Distribution_Territory", rs.getString("Distribution_Territory"));
			validatejson.put("Team", rs.getString("Team"));	
			validatejson.put("Player_used", rs.getString("Player_used"));
			validatejson.put("Product_Type", rs.getString("Product_Type"));	
			validatejson.put("imagepath", rs.getString("imagepath"));
			validatejson.put("imagename", rs.getString("imagename"));
		}else
		{
			validatejson.put("id", rs.getInt("id"));	
			validatejson.put("Templet_Name", rs.getString("Templet_Name"));	
			validatejson.put("Product_Name", rs.getString("Product_Name"));
			validatejson.put("Product_Description", rs.getString("Product_Description"));	
			validatejson.put("Merchandise_Type", rs.getString("Merchandise_Type"));
			validatejson.put("Retail_Price", rs.getString("Retail_Price"));	
			validatejson.put("Property", rs.getString("Property"));
			validatejson.put("Lunch_Year", rs.getString("Lunch_Year"));	
			validatejson.put("Lunch_Season", rs.getString("Lunch_Season"));
			validatejson.put("Event_Special", rs.getString("Event_Special"));	
			validatejson.put("Distribution_Territory", rs.getString("Distribution_Territory"));
			validatejson.put("Team", rs.getString("Team"));	
			validatejson.put("Player_used", rs.getString("Player_used"));
			validatejson.put("Product_Type", rs.getString("Product_Type"));	
			validatejson.put("imagepath", rs.getString("imagepath"));
			validatejson.put("imagename", rs.getString("imagename"));
			
			
		}
	
			jsa.put(validatejson);
		
	}
	

	conn.close();
	}
	catch(Exception ex)
	{
	System.out.println("search data error="+ex);
	}
	return jsa.toString();
	
	}
	
	
	public static String searchDatamessageEdit(String slq)
	{
		System.out.println(slq);
		JSONArray jsa = new JSONArray();	
		
	try
	{
		
		conn = ConnectionManager.getConnection();
		stmt = conn.createStatement();

	
	rs = stmt.executeQuery(slq);


	while (rs.next()) {


		JSONObject validatejson = new JSONObject();
		
			validatejson.put("id", rs.getInt("id"));	
			validatejson.put("Templet_Name", rs.getString("Templet_Name"));	
			validatejson.put("Product_Name", rs.getString("Product_Name"));
			validatejson.put("Product_Description", rs.getString("Product_Description"));	
			validatejson.put("Merchandise_Type", rs.getString("Merchandise_Type"));
			validatejson.put("Retail_Price", rs.getString("Retail_Price"));	
			validatejson.put("Property", rs.getString("Property"));
			validatejson.put("Lunch_Year", rs.getString("Lunch_Year"));	
			validatejson.put("Lunch_Season", rs.getString("Lunch_Season"));
			validatejson.put("Event_Special", rs.getString("Event_Special"));	
			validatejson.put("Distribution_Territory", rs.getString("Distribution_Territory"));
			validatejson.put("Team", rs.getString("Team"));	
			validatejson.put("Player_used", rs.getString("Player_used"));
			validatejson.put("Product_Type", rs.getString("Product_Type"));	
			validatejson.put("imagepath", rs.getString("imagepath"));
			validatejson.put("imagename", rs.getString("imagename"));
		
	
			jsa.put(validatejson);
		
	}
	

	conn.close();
	}
	catch(Exception ex)
	{
	System.out.println("search data error="+ex);
	}
	return jsa.toString();
	
	}
	
	
	
	 public static void insertmessage(String sql) throws UnsupportedEncodingException {
		
	        try {
	        	conn = ConnectionManager.getConnection();
	    		stmt = conn.createStatement();
	    		 
	    		 System.out.println("sql"+sql);
	    		 stmt.execute(sql);
	    		 
	        } catch (SQLException se) {
	        	System.out.println("putdata error="+se);
	        }
	    }
	

	

	
		

		public static void updateData(String thresh)
		{
		try
		{

			conn = ConnectionManager.getConnection();
			stmt = conn.createStatement();
		
		System.out.println("thresh :-" + thresh);
	    stmt.executeUpdate(thresh);
		
		
	    conn.close();
		}
		catch(SQLException se)
		{
		System.out.println("putdata error="+se);
		}
		}
		
		


	

	

}
