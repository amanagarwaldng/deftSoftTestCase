package demo.test;

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

/**
 * Servlet implementation class delete
 */
public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delete() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	

		 StringBuilder sb = new StringBuilder();
		    BufferedReader br = request.getReader();
		    String str;
		    while( (str = br.readLine()) != null ){
		        sb.append(str);
		    }    
		   System.out.println(sb.toString());
		
		   final JSONObject obj = new JSONObject(sb.toString());
		 
		  int status1=obj.getInt("filrname");
		  
		  System.out.println("status1" + status1);
		   String sql1="";
	
		   
			   sql1="DELETE FROM task.submitnewdesign WHERE id='"+status1+"'";
			   
		  
		
		 Mycon.insertmessage(sql1);
		   
	
	

		    response.getWriter().write("Ok"); 
	}


	

}
